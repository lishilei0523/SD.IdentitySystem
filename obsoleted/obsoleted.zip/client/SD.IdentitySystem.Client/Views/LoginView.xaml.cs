﻿namespace SD.IdentitySystem.Client.Views
{
    /// <summary>
    /// LoginView.xaml 的交互逻辑
    /// </summary>
    public partial class LoginView
    {
        public LoginView()
        {
            this.InitializeComponent();
        }
    }
}
