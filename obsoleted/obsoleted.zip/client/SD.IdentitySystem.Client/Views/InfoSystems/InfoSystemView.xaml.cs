﻿using System.Windows.Controls;

namespace SD.IdentitySystem.Client.Views.InfoSystems
{
    /// <summary>
    /// InfoSystemView.xaml 的交互逻辑
    /// </summary>
    public partial class InfoSystemView : UserControl
    {
        public InfoSystemView()
        {
            InitializeComponent();
        }
    }
}
