﻿namespace SD.IdentitySystem.Client.Views.Servers
{
    /// <summary>
    /// ServerView.xaml 的交互逻辑
    /// </summary>
    public partial class ServerView
    {
        public ServerView()
        {
            this.InitializeComponent();
        }
    }
}
