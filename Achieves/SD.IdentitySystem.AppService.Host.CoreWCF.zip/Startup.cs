using CoreWCF;
using CoreWCF.Configuration;
using CoreWCF.Description;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using SD.IdentitySystem.AppService.Implements;
using SD.IdentitySystem.IAppService.Interfaces;

namespace SD.IdentitySystem.AppService.Host
{
    /// <summary>
    /// Ӧ�ó���������
    /// </summary>
    public class Startup
    {
        /// <summary>
        /// ���÷���
        /// </summary>
        public void ConfigureServices(IServiceCollection services)
        {
            //����WCF����
            services.AddServiceModelServices();
        }

        /// <summary>
        /// ����Ӧ�ó���
        /// </summary>
        public void Configure(IApplicationBuilder appBuilder)
        {
            //����WCF����
            appBuilder.UseServiceModel(builder =>
            {
                builder.AddService<AuthenticationContract>();
                builder.AddServiceEndpoint<AuthenticationContract, IAuthenticationContract>(new NetTcpBinding(), "/Hosts/AuthenticationContract.svc");

                builder.ConfigureServiceHostBase<AuthenticationContract>(serviceHost =>
                {
                    //serviceHost.Description.Behaviors.Add();
                    foreach (ServiceEndpoint serviceEndpoint in serviceHost.Description.Endpoints)
                    {
                        //serviceEndpoint.EndpointBehaviors.Add();
                    }
                });
            });
        }
    }
}
