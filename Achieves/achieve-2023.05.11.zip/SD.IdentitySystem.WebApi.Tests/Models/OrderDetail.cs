﻿namespace SD.IdentitySystem.WebApi.Tests.Models
{
    public class OrderDetail
    {

        public string Number { get; set; }
        public string Description { get; set; }
    }
}
