﻿namespace SD.IdentitySystem.WebApi.Tests.Models
{
    public class PriceParam
    {
        public double Price { get; set; }
        public string Description { get; set; }
    }
}
