﻿using Xamarin.Forms;

namespace SD.IdentitySystem.Mobile.Views.Home
{
    /// <summary>
    /// 登录页视图
    /// </summary>
    public partial class LoginView : ContentPage
    {
        public LoginView()
        {
            this.InitializeComponent();
        }
    }
}
