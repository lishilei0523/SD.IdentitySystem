﻿using Xamarin.Forms;

namespace SD.IdentitySystem.Mobile.Views.Home
{
    /// <summary>
    /// 首页视图
    /// </summary>
    public partial class IndexView : ContentPage
    {
        public IndexView()
        {
            this.InitializeComponent();
        }
    }
}
