﻿// ReSharper disable once CheckNamespace
namespace SD.IdentitySystem.LicenseManager
{
    /// <summary>
    /// 常量
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// 许可证文件名
        /// </summary>
        public const string LicenseFileName = "License.key";
    }
}