﻿using SD.Infrastructure.Repository.EntityFramework.Base;

namespace SD.IdentitySystem.Repository.Base
{
    /// <summary>
    /// EF上下文
    /// </summary>
    internal class DbSession : BaseDbSession
    {

    }
}
